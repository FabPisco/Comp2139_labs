﻿namespace Gbc_Travel_Group_One.Models
{
    public class Hotel
    {
        public int Id { get; set; }
        public required string HotelName { get; set; }
        public required string City { get; set; }
        public required string Address { get; set; }
        public int NumberOfRooms { get; set; }
        public decimal PricePerNight { get; set; }
    }
}