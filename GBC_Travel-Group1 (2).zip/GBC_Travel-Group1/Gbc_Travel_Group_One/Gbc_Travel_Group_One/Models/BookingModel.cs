﻿namespace booking.Models
{
    public class BookingModel
    {
        public required string ServiceType { get; set; }
        public required string ServiceName { get; set; }
        public decimal Price { get; set; }
        public int Availability { get; set; }
        // Add more properties as needed
    }
}