﻿namespace Gbc_Travel_Group_One.Models
{
    public class CarRental
    {
        public int Id { get; set; }
        public required string CarModel { get; set; }
        public required string RentalCompany { get; set; }
        public required string PickupLocation { get; set; }
        public required string DropOffLocation { get; set; }
        public DateTime PickupDate { get; set; }
        public DateTime DropOffDate { get; set; }
        public decimal DailyRate { get; set; }
    }
}