﻿using Gbc_Travel_Group_One.Data;
using Gbc_Travel_Group_One.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Gbc_Travel_Group_One.Controllers
{
    [Route("User")]
    public class UserController : Controller
    {
        private readonly ApplicationDbContext _context;

        public UserController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet("")]
        public async Task<IActionResult> Index(string SortOrder, string SearchString)
        {
            ViewData[""] = SearchString;
            var users = from p in _context.Users
                          select p;
            if (!String.IsNullOrEmpty(SearchString))
            {
                users = users.Where(p => p.FirstName.Contains(SearchString));
            }

            ViewData["LastNameSortParam"] = SortOrder == "last_name_sort" ? "last_name_sort_desc" : "last_name_sort";
            ViewData["FirstNameSortParam"] = SortOrder == "first_name_sort" ? "first_name_sort_desc" : "first_name_sort";
            ViewData["PhoneSortParam"] = SortOrder == "phone_sort" ? "phone_sort_desc" : "phone_sort";
            ViewData["EmailSortParam"] = SortOrder == "email_sort" ? "email_sort_desc" : "email_sort";

            switch (SortOrder)
            {
                case "last_name_sort":
                    users = users.OrderBy(p => p.LastName);
                    break;
                case "last_name_sort_desc":
                    users = users.OrderByDescending(p => p.LastName);
                    break;
                case "first_name_sort":
                    users = users.OrderBy(p => p.FirstName);
                    break;
                case "first_name_sort_desc":
                    users = users.OrderByDescending(p => p.FirstName);
                    break;
                case "phone_sort":
                    users = users.OrderBy(p => p.Phone);
                    break;
                case "phone_sort_desc":
                    users = users.OrderByDescending(p => p.Phone);
                    break;
                case "email_sort":
                    users = users.OrderBy(p => p.Email);
                    break;
                case "email_sort_desc":
                    users = users.OrderByDescending(p => p.Email);
                    break;
                default:
                    users = users.OrderBy(p => p.FirstName);
                    break;

            }
            return View(await users.AsNoTracking().ToListAsync());


        }
        public IActionResult Index()
        {
            var users = _context.Users.ToList();
            return View(users);
        }

        [HttpGet("Details/{id:int}")]
        public IActionResult Details(int id)
        {
            var user = _context.Users.FirstOrDefault(u => u.Id == id);
            return View(user);
        }

        [HttpGet("Create")]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost("Create")]
        [ValidateAntiForgeryToken]
        public IActionResult Create(User user)
        {
            if (ModelState.IsValid)
            {
                _context.Add(user);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(user);
        }

        [HttpGet("Edit/{id:int}")]
        public IActionResult Edit(int id)
        {
            var user = _context.Users.Find(id);
            if (user == null)
            {
                return NotFound();
            }
            return View(user);
        }

        [HttpPost("Edit/{id:int}")]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, [Bind("Id, LastName, FirstName, Phone, Email")] User user)
        {
            if (id != user.Id)
            {
                return NotFound();
            }
            if (ModelState.IsValid)
            {
                _context.Update(user);
                _context.SaveChanges();

                return RedirectToAction(nameof(Index));
            }
            return View(user);
        }

        [HttpGet("Delete/{id:int}")]
        public IActionResult Delete(int id)
        {
            var user = _context.Users.FirstOrDefault(u => u.Id == id);
            if (user == null)
            {
                return NotFound();
            }
            return View(user);
        }

        [HttpPost("DeleteConfirmed/{id:int}")]
        [HttpPost, ActionName("DeleteConfirmed")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            var user = _context.Users.Find(id);
            if (user != null)
            {
                _context.Users.Remove(user);
                _context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            return NotFound();
        }

        [HttpGet("Search/{searchString?}")]
        public async Task<IActionResult> Search(string searchString)
        {
            var userQuery = from p in _context.Users
                            select p;

            bool searchPerformed = !String.IsNullOrEmpty(searchString);
            if (searchPerformed)
            {
                userQuery = userQuery.Where(p => p.LastName.Contains(searchString)
                                                || p.FirstName.Contains(searchString)
                                                || p.Phone.Contains(searchString)
                                                || p.Email.Contains(searchString));
            }
            var users = await userQuery.ToListAsync();
            ViewData["SearchPerformed"] = searchPerformed;
            ViewData["SearchString"] = searchString;
            return View("Index", users);
        }
    }
}
