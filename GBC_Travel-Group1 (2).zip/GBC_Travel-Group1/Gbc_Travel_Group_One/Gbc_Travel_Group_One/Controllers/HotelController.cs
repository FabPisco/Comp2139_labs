﻿using Gbc_Travel_Group_One.Data;
using Gbc_Travel_Group_One.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Runtime.InteropServices;

namespace Gbc_Travel_Group_One.Controllers
{
    [Route("Hotel")]
    public class HotelController : Controller
    {
        private readonly ApplicationDbContext _context;

        public HotelController(ApplicationDbContext context)
        {
            _context = context;
        }
        [HttpGet("")]
        public async Task<IActionResult> Index(string SortOrder, string SearchString)
        {
            ViewData[""] = SearchString;
            var hotels = from p in _context.Hotels
                         select p;
            if (!String.IsNullOrEmpty(SearchString))
            {
                hotels = hotels.Where(p => p.HotelName.Contains(SearchString));
            }

            
            ViewData["HotelNameSortParam"] = SortOrder == "hotel_name_sort" ? "hotel_name_sort_desc" : "hotel_name_sort";
            ViewData["CitySortParam"] = SortOrder == "city_sort" ? "city_sort_desc" : "city_sort";
            ViewData["AddressSortParam"] = SortOrder == "address_sort" ? "address_sort_desc" : "address_sort";
            ViewData["NumberOfRoomsSortParam"] = SortOrder == "number_of_rooms_sort" ? "number_of_rooms_sort_desc" : "number_of_rooms_sort";
            ViewData["PricePerNightSortParam"] = SortOrder == "price_per_night_sort" ? "price_per_night_sort_desc" : "price_per_night_sort";
            
            switch (SortOrder)
            {
                case "hotel_name_sort":
                    hotels = hotels.OrderBy(p => p.HotelName);
                    break;
                case "hotel_name_sort_desc":
                    hotels = hotels.OrderByDescending(p => p.HotelName);
                    break;
                case "city_sort":
                    hotels = hotels.OrderBy(p => p.City);
                    break;
                case "city_sort_desc":
                    hotels = hotels.OrderByDescending(p => p.City);
                    break;
                case "address_sort":
                    hotels = hotels.OrderBy(p => p.Address);
                    break;
                case "address_sort_desc":
                    hotels = hotels.OrderByDescending(p => p.Address);
                    break;
                case "number_of_rooms_sort":
                    hotels = hotels.OrderBy(p => p.NumberOfRooms);
                    break;
                case "number_of_rooms_sort_desc":
                    hotels = hotels.OrderByDescending(p => p.NumberOfRooms);
                    break;
                case "price_per_night_sort":
                    hotels = hotels.OrderBy(p => p.PricePerNight);
                    break;
                case "price_per_night_sort_desc":
                    hotels = hotels.OrderByDescending(p => p.PricePerNight);
                    break;
                default:
                    hotels = hotels.OrderBy(p => p.HotelName);
                    break;

            }
            return View(await hotels.AsNoTracking().ToListAsync());
        }
        public IActionResult Index()
        {
            var hotels = _context.Hotels.ToList();
            return View(hotels);
        }
        [HttpGet("Details/{id:int}")]
        public IActionResult Details(int id)
        {
            var hotel = _context.Hotels.FirstOrDefault(h => h.Id == id);
            return View(hotel);
        }
        [HttpGet("Create")]
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost("Create")]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Hotel hotel) 
        {
            if (ModelState.IsValid)
            {
                _context.Add(hotel);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(hotel);
        }
        [HttpGet("Edit/{id:int}")]
        public IActionResult Edit(int id)
        {
            var hotel = _context.Hotels.Find(id);
            if (hotel == null)
            {
                return NotFound();
            }
            return View(hotel);
        }
        [HttpPost("Edit/{id:int}")]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, [Bind("Id, HotelName, City, Address, NumberOfRooms, PricePerNight")] Hotel hotel)
        {
            if (id != hotel.Id)
            {
                return NotFound();
            }
            if (ModelState.IsValid)
            {
                _context.Update(hotel);
                _context.SaveChanges();

                return RedirectToAction(nameof(Index));
            }
            return View(hotel);
        }
        [HttpGet("Delete/{id:int}")]
        public IActionResult Delete(int id)
        {
            var hotel = _context.Hotels.FirstOrDefault(h => h.Id == id);
            if (hotel == null)
            {
                return NotFound();
            }
            return View(hotel);
        }
        [HttpPost("DeleteConfirmed/{id:int}")]
        [HttpPost, ActionName("DeleteConfirmed")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            var hotel = _context.Hotels.Find(id);
            if (hotel != null)
            {
                _context.Hotels.Remove(hotel);
                _context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            return NotFound();
        }
        [HttpGet("Search/{searchString?}")]
        public async Task<IActionResult> Search(string searchString)
        {
            var hotelsQuery = from p in _context.Hotels
                               select p;


            bool searchPerformed = !String.IsNullOrEmpty(searchString);
            if (searchPerformed)
            {
                hotelsQuery = hotelsQuery.Where(p => p.HotelName.Contains(searchString)
                                               || p.City.Contains(searchString)
                                               || p.Address.Contains(searchString));
            }
            var hotels = await hotelsQuery.ToListAsync();
            ViewData["SearchPerformed"] = searchPerformed;
            ViewData["SearchString"] = searchString;
            return View("Index", hotels);
        }
    }
}
