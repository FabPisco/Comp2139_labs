﻿using Gbc_Travel_Group_One.Data;
using Gbc_Travel_Group_One.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.CodeAnalysis;

namespace Gbc_Travel_Group_One.Controllers
{
    [Route("Flight")]
    public class FlightController : Controller
    {
        private readonly ApplicationDbContext _context;

        public FlightController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet("")]
        public async Task<IActionResult> Index(string SortOrder, string SearchString)
        {
            ViewData[""] = SearchString;
            var flights = from p in _context.Flights
                          select p;
            if (!String.IsNullOrEmpty(SearchString))
            {
                flights = flights.Where(p => p.FlightNumber.Contains(SearchString));
            }

            ViewData["FlightNumberSortParam"] = SortOrder == "flight_number_sort" ? "flight_number_sort_desc" : "flight_number_sort";
            ViewData["DepartureCitySortParam"] = SortOrder == "departure_city_sort" ? "departure_city_sort_desc" : "departure_city_sort";
            ViewData["ArrivalCitySortParam"] = SortOrder == "arrival_city_sort" ? "arrival_city_sort_desc" : "arrival_city_sort";
            ViewData["DepartureDateSortParam"] = SortOrder == "departure_date_sort" ? "departure_date_sort_desc" : "departure_date_sort";
            ViewData["PriceSortParam"] = SortOrder == "price_sort" ? "price_sort_desc" : "price_sort";

            switch (SortOrder)
            {
                case "flight_number_sort":
                    flights = flights.OrderBy(p => p.FlightNumber);
                    break;
                case "flight_number_sort_desc":
                    flights = flights.OrderByDescending(p => p.FlightNumber);
                    break;
                case "departure_city_sort":
                    flights = flights.OrderBy(p => p.DepartureCity);
                    break;
                case "departure_city_sort_desc":
                    flights = flights.OrderByDescending(p => p.DepartureCity);
                    break;
                case "arrival_city_sort":
                    flights = flights.OrderBy(p => p.ArrivalCity);
                    break;
                case "arrival_city_sort_desc":
                    flights = flights.OrderByDescending(p => p.ArrivalCity);
                    break;
                case "departure_date_sort":
                    flights = flights.OrderBy(p => p.DepartureDate);
                    break;
                case "departure_date_desc_sort":
                    flights = flights.OrderByDescending(p => p.DepartureDate);
                    break;
                case "price_sort":
                    flights = flights.OrderBy(p => p.Price);
                    break;
                case "price_sort_desc":
                    flights = flights.OrderByDescending(p => p.Price);
                    break;
                default:
                    flights = flights.OrderBy(p => p.FlightNumber);
                    break;

            }
            return View(await flights.AsNoTracking().ToListAsync());


        }
        public IActionResult Index()
        {
            var flights = _context.Flights.ToList();
            return View(flights);
        }
        [HttpGet("Details/{id:int}")]
        public IActionResult Details(int id)
        {
            var flight = _context.Flights.FirstOrDefault(f => f.Id == id);
            return View(flight);
        }

        [HttpGet("Create")]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost("Create")]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Flight flight) // Adjust the parameter type based on the model
        {
            if (ModelState.IsValid)
            {
                _context.Add(flight);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(flight);
        }
        [HttpGet("Edit/{id:int}")]
        public IActionResult Edit(int id)
        {
            var flight = _context.Flights.Find(id);
            if (flight == null)
            {
                return NotFound();
            }
            return View(flight);
        }
        [HttpPost("Edit/{id:int}")]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, [Bind("Id, FlightNumber, DepartureCity, ArrivalCity, DepartureDate, Price")] Flight flight)
        {
            if (id != flight.Id)
            {
                return NotFound();
            }
            if (ModelState.IsValid)
            {
                _context.Update(flight);
                _context.SaveChanges();

                return RedirectToAction(nameof(Index));
            }
            return View(flight);
        }
        [HttpGet("Delete/{id:int}")]
        public IActionResult Delete(int id)
        {
            var flight = _context.Flights.FirstOrDefault(f => f.Id == id);
            if (flight == null)
            {
                return NotFound();
            }
            return View(flight);
        }
        [HttpPost("DeleteConfirmed/{id:int}")]
        [HttpPost, ActionName("DeleteConfirmed")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            var flight = _context.Flights.Find(id);
            if (flight != null)
            {
                _context.Flights.Remove(flight);
                _context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            // Handle the case where the project might not be found
            return NotFound();
        }
        [HttpGet("Search/{searchString?}")]
        public async Task<IActionResult> Search(string searchString)
        {
            var flightsQuery = from p in _context.Flights
                               select p;


            bool searchPerformed = !String.IsNullOrEmpty(searchString);
            if (searchPerformed)
            {
                flightsQuery = flightsQuery.Where(p => p.FlightNumber.Contains(searchString)
                                               || p.DepartureCity.Contains(searchString)
                                               || p.ArrivalCity.Contains(searchString));
            }
            var flights = await flightsQuery.ToListAsync();
            ViewData["SearchPerformed"] = searchPerformed;
            ViewData["SearchString"] = searchString;
            return View("Index", flights);
        }
        // Add other CRUD actions as needed (Create, Edit, Delete)
    }
}