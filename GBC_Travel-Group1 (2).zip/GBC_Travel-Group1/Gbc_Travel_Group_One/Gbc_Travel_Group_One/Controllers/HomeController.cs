using Gbc_Travel_Group_One.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace Gbc_Travel_Group_One.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [HttpGet]
        public IActionResult GeneralSearch(string searchType, string searchString)
        {
            if (searchType == "Flight")
            {
                return RedirectToAction("Search", "Flight", new { searchString });
            }
            else if (searchType == "Hotel")
            {
                return RedirectToAction("Search", "Hotel", new { searchString });
            }
            else if (searchType == "CarRental")
            {
                return RedirectToAction("Search", "CarRental", new { searchString });
            }
            else if (searchType == "User")
            {
                return RedirectToAction("Search", "User", new { searchString });
            }
            return RedirectToAction("Index", "Home");
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
