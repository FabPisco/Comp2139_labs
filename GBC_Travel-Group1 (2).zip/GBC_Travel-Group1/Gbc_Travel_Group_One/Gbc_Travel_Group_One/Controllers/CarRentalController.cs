﻿using Gbc_Travel_Group_One.Data;
using Gbc_Travel_Group_One.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Gbc_Travel_Group_One.Controllers
{
    [Route("CarRental")]
    public class CarRentalController : Controller
    {
        private readonly ApplicationDbContext _context;

        public CarRentalController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet("")]
        public async Task<IActionResult> Index(string SortOrder, string SearchString)
        {
            ViewData[""] = SearchString;
            var carRentals = from p in _context.CarRentals
                          select p;
            if (!String.IsNullOrEmpty(SearchString))
            {
                carRentals = carRentals.Where(p => p.CarModel.Contains(SearchString));
            }
            ViewData["CarModelSortParam"] = SortOrder == "car_model_sort" ? "car_model_sort_desc" : "car_model_sort";
            ViewData["RentalCompanySortParam"] = SortOrder == "rental_company_sort" ? "rental_company_sort_desc" : "rental_company_sort";
            ViewData["PickupLocationSortParam"] = SortOrder == "pickup_location_sort" ? "pickup_location_sort_desc" : "pickup_location_sort";
            ViewData["DropOffLocationSortParam"] = SortOrder == "dropoff_location_sort" ? "dropoff_location_sort_desc" : "dropoff_location_sort";
            ViewData["PickupDateSortParam"] = SortOrder == "pickup_date_sort" ? "pickup_date_sort_desc" : "pickup_date_sort";
            ViewData["DropOffDateSortParam"] = SortOrder == "dropoff_date_sort" ? "dropoff_date_sort_desc" : "dropoff_date_sort";
            ViewData["DailyRateSortParam"] = SortOrder == "daily_rate_sort" ? "daily_rate_sort_desc" : "daily_rate_sort";
           
            switch (SortOrder)
            {
                case "car_model_sort":
                    carRentals = carRentals.OrderBy(p => p.CarModel);
                    break;
                case "car_model_sort_desc":
                    carRentals = carRentals.OrderByDescending(p => p.CarModel);
                    break;
                case "rental_company_sort":
                    carRentals = carRentals.OrderBy(p => p.RentalCompany);
                    break;
                case "rental_company_sort_desc":
                    carRentals = carRentals.OrderByDescending(p => p.RentalCompany);
                    break;
                case "pickup_location_sort":
                    carRentals = carRentals.OrderBy(p => p.PickupLocation);
                    break;
                case "pickup_location_sort_desc":
                    carRentals = carRentals.OrderByDescending(p => p.PickupLocation);
                    break;
                case "dropoff_location_sort":
                    carRentals = carRentals.OrderBy(p => p.DropOffLocation);
                    break;
                case "dropoff_location_sort_desc":
                    carRentals = carRentals.OrderByDescending(p => p.DropOffLocation);
                    break;
                case "pickup_date_sort":
                    carRentals = carRentals.OrderBy(p => p.PickupDate);
                    break;
                case "pickup_date_sort_desc":
                    carRentals = carRentals.OrderByDescending(p => p.PickupDate);
                    break;
                case "dropoff_date_sort":
                    carRentals = carRentals.OrderBy(p => p.DropOffDate);
                    break;
                case "dropoff_date_sort_desc":
                    carRentals = carRentals.OrderByDescending(p => p.DropOffDate);
                    break;
                case "daily_rate_sort":
                    carRentals = carRentals.OrderBy(p => p.DailyRate);
                    break;
                case "daily_rate_sort_desc":
                    carRentals = carRentals.OrderByDescending(p => p.DailyRate);
                    break;
                default:
                    carRentals = carRentals.OrderBy(p => p.CarModel);
                    break;

            }
            return View(await carRentals.AsNoTracking().ToListAsync());
        }

        public IActionResult Index()
        {
            var carRentals = _context.CarRentals.ToList();
            return View(carRentals);
        }
        [HttpGet("Details/{id:int}")]
        public IActionResult Details(int id)
        {
            var carRental = _context.CarRentals.FirstOrDefault(c => c.Id == id);
            return View(carRental);
        }
        [HttpGet("Create")]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost("Create")]
        [ValidateAntiForgeryToken]
        public IActionResult Create(CarRental carRental) 
        {
            if (ModelState.IsValid)
            {
                _context.Add(carRental);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(carRental);
        }
        [HttpGet("Edit/{id:int}")]
        public IActionResult Edit(int id)
        {
            var carRental = _context.CarRentals.Find(id);
            if (carRental == null)
            {
                return NotFound();
            }
            return View(carRental);
        }
        [HttpPost("Edit/{id:int}")]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, [Bind("Id, CarModel, RentalCompany, PickupLocation, DropOffLocation, PickupDate, DropOffDate, DailyRate")] CarRental carRental)
        {
            if (id != carRental.Id)
            {
                return NotFound();
            }
            if (ModelState.IsValid)
            {
                _context.Update(carRental);
                _context.SaveChanges();

                return RedirectToAction(nameof(Index));
            }
            return View(carRental);
        }
        [HttpGet("Delete/{id:int}")]
        public IActionResult Delete(int id)
        {
            var carRental = _context.CarRentals.FirstOrDefault(c => c.Id == id);
            if (carRental == null)
            {
                return NotFound();
            }
            return View(carRental);
        }
        [HttpPost("DeleteConfirmed/{id:int}")]
        [HttpPost, ActionName("DeleteConfirmed")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            var carRental = _context.CarRentals.Find(id);
            if (carRental != null)
            {
                _context.CarRentals.Remove(carRental);
                _context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            return NotFound();
        }
        [HttpGet("Search/{searchString?}")]
        public async Task<IActionResult> Search(string searchString)
        {
            var carRentalQuery = from p in _context.CarRentals
                              select p;


            bool searchPerformed = !String.IsNullOrEmpty(searchString);
            if (searchPerformed)
            {
                carRentalQuery = carRentalQuery.Where(p => p.CarModel.Contains(searchString)
                                               || p.DropOffLocation.Contains(searchString)
                                               || p.RentalCompany.Contains(searchString)
                                               || p.PickupLocation.Contains(searchString));
            }
            var carRentals = await carRentalQuery.ToListAsync();
            ViewData["SearchPerformed"] = searchPerformed;
            ViewData["SearchString"] = searchString;
            return View("Index", carRentals);
        }
    }
}