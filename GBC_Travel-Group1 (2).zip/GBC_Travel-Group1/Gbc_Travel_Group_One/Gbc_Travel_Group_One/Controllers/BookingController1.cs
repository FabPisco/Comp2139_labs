﻿using Microsoft.AspNetCore.Mvc;
using booking.Models;

namespace booking.Controllers
{

    public class BookingController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Book(BookingModel booking)
        {
            if (booking is null)
            {
                throw new ArgumentNullException(nameof(booking));
            }
            // Process booking, save to database, etc.
            //  you should implement the actual logic.

            return RedirectToAction("Confirmation");
        }

        public IActionResult Confirmation()
        {
            return View();
        }
    }
}