﻿using Gbc_Travel_Group_One.Models;
using Microsoft.EntityFrameworkCore;

namespace Gbc_Travel_Group_One.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<Flight> Flights { get; set; }
        public DbSet<Hotel> Hotels { get; set; }
        public DbSet<CarRental> CarRentals { get; set; }
        public DbSet<User> Users { get; set; } 
    }
}